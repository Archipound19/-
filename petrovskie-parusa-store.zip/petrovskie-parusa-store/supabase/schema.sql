-- Выполнить в Supabase SQL Editor.
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 category text not null default 'Другое',
 description text,
 price numeric(10,2) not null check (price >= 0),
 unit text not null default 'кг',
 image_url text,
 is_active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(),
 customer_name text not null,
 phone text not null,
 comment text,
 payment_method text not null check (payment_method in ('cash_on_pickup','online')),
 fulfillment_method text not null default 'pickup' check (fulfillment_method='pickup'),
 items jsonb not null,
 total numeric(12,2) not null,
 status text not null default 'new',
 created_at timestamptz not null default now()
);
alter table public.products enable row level security;
alter table public.orders enable row level security;
-- Публично читаются только активные товары.
create policy "Public can read active products" on public.products for select using (is_active=true);
-- Администратор: в Supabase Auth у пользователя в app_metadata должно быть role=admin.
create policy "Admins manage products" on public.products for all
 using ((auth.jwt()->'app_metadata'->>'role')='admin')
 with check ((auth.jwt()->'app_metadata'->>'role')='admin');
-- Заказы создаются только серверным API с service role key; публичное чтение запрещено.
-- Администратору можно разрешить чтение заказов:
create policy "Admins read orders" on public.orders for select
 using ((auth.jwt()->'app_metadata'->>'role')='admin');
-- Индексы
create index if not exists products_category_idx on public.products(category);
create index if not exists orders_created_at_idx on public.orders(created_at desc);


-- Демонстрационные товары для первого запуска (можно удалить или заменить из админки).
insert into public.products (name, category, description, price, unit, image_url, is_active) values
('Говядина для стейка','Говядина','Мраморная говядина, охлаждённая',1290,'кг','https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=800',true),
('Филе куриное','Птица','Нежное куриное филе',490,'кг','https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=800',true),
('Свинина для запекания','Свинина','Отборный охлаждённый кусок',620,'кг','https://images.unsplash.com/photo-1602470520998-f4a52199a3d6?w=800',true),
('Фарш домашний','Фарш','Говядина и свинина',540,'кг','https://images.unsplash.com/photo-1588347818036-4c9f9a5e7b1d?w=800',true),
('Рёбра BBQ','Полуфабрикаты','Подготовлены для запекания',790,'кг','https://images.unsplash.com/photo-1544025162-d76694265947?w=800',true),
('Бараньи рёбрышки','Баранина','Свежая баранина',1150,'кг','https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=800',true);
