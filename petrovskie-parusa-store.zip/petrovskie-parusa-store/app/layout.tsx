import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Петровские паруса — мясная лавка",
  description: "Свежие мясные продукты. Заказ онлайн, самовывоз в Коммунарке."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}