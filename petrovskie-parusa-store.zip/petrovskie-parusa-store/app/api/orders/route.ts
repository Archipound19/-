import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
export async function POST(req:Request) {
 try {
  const body=await req.json();
  if(!body.customer_name||!body.phone||!Array.isArray(body.items)||!body.items.length) return NextResponse.json({error:"Заполните имя, телефон и корзину."},{status:400});
  if(!process.env.NEXT_PUBLIC_SUPABASE_URL||!process.env.SUPABASE_SERVICE_ROLE_KEY) return NextResponse.json({error:"База данных ещё не подключена. Настройте Supabase по инструкции."},{status:503});
  const db=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY);
  const ids=body.items.map((x:any)=>String(x.product_id));
  const {data:products,error}=await db.from("products").select("id,name,price,unit,is_active").in("id",ids).eq("is_active",true);
  if(error||!products||products.length!==ids.length)return NextResponse.json({error:"Один или несколько товаров недоступны. Обновите каталог."},{status:400});
  const items=products.map((p:any)=>{const input=body.items.find((x:any)=>String(x.product_id)===String(p.id));const quantity=Math.max(1,Math.min(99,Number(input.quantity)||1));return {product_id:p.id,name:p.name,price:p.price,unit:p.unit,quantity,line_total:p.price*quantity};});
  const total=items.reduce((s:any,x:any)=>s+x.line_total,0);
  const {data,error:insertError}=await db.from("orders").insert({customer_name:String(body.customer_name).slice(0,120),phone:String(body.phone).slice(0,40),comment:String(body.comment||"").slice(0,1000),payment_method:body.payment_method==="online"?"online":"cash_on_pickup",fulfillment_method:"pickup",items,total,status:"new"}).select("id").single();
  if(insertError)throw insertError;
  return NextResponse.json({ok:true,order_number:String(insert.data.id).slice(0,8).toUpperCase()});
 } catch(e) { return NextResponse.json({error:"Ошибка оформления заказа. Попробуйте позже."},{status:500}); }
}