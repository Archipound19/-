 "use client";
import { useEffect, useMemo, useState } from "react";
import { ShoppingBag, Search, MapPin, Phone, Plus, Minus, X, Menu } from "lucide-react";

type Product = { id:string; name:string; category:string; description:string|null; price:number; unit:string; image_url:string|null; is_active:boolean };
const demo: Product[] = [
 {id:"1",name:"Говядина для стейка",category:"Говядина",description:"Мраморная говядина, охлаждённая",price:1290,unit:"кг",image_url:"https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=800",is_active:true},
 {id:"2",name:"Филе куриное",category:"Птица",description:"Нежное куриное филе",price:490,unit:"кг",image_url:"https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=800",is_active:true},
 {id:"3",name:"Свинина для запекания",category:"Свинина",description:"Отборный охлаждённый кусок",price:620,unit:"кг",image_url:"https://images.unsplash.com/photo-1602470520998-f4a52199a3d6?w=800",is_active:true},
 {id:"4",name:"Фарш домашний",category:"Фарш",description:"Говядина и свинина",price:540,unit:"кг",image_url:"https://images.unsplash.com/photo-1588347818036-4c9f9a5e7b1d?w=800",is_active:true},
 {id:"5",name:"Рёбра BBQ",category:"Полуфабрикаты",description:"Подготовлены для запекания",price:790,unit:"кг",image_url:"https://images.unsplash.com/photo-1544025162-d76694265947?w=800",is_active:true},
 {id:"6",name:"Бараньи рёбрышки",category:"Баранина",description:"Свежая баранина",price:1150,unit:"кг",image_url:"https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=800",is_active:true}
];
const money = (n:number) => new Intl.NumberFormat("ru-RU").format(n) + " ₽";
export default function Home() {
 const [products,setProducts]=useState<Product[]>(demo), [category,setCategory]=useState("Все"), [search,setSearch]=useState("");
 const [cart,setCart]=useState<Record<string,number>>({}), [checkout,setCheckout]=useState(false), [mobile,setMobile]=useState(false), [notice,setNotice]=useState("");
 useEffect(()=>{ fetch("/api/products").then(r=>r.ok?r.json():null).then(d=>{if(d?.length)setProducts(d)}).catch(()=>{}); },[]);
 const categories=["Все",...Array.from(new Set(products.map(p=>p.category)))];
 const shown=useMemo(()=>products.filter(p=>(category==="Все"||p.category===category)&&p.name.toLowerCase().includes(search.toLowerCase())),[products,category,search]);
 const total=products.reduce((s,p)=>s+(cart[p.id]||0)*p.price,0);
 const count=Object.values(cart).reduce((a,b)=>a+b,0);
 const add=(id:string)=>setCart(c=>({...c,[id]:(c[id]||0)+1}));
 const change=(id:string,d:number)=>setCart(c=>{const n=(c[id]||0)+d;const x={...c};if(n<=0)delete x[id];else x[id]=n;return x});
 async function submit(e:React.FormEvent<HTMLFormElement>){
  e.preventDefault(); const fd=new FormData(e.currentTarget);
  const items=products.filter(p=>cart[p.id]).map(p=>({product_id:p.id,name:p.name,quantity:cart[p.id]}));
  const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customer_name:fd.get("name"),phone:fd.get("phone"),comment:fd.get("comment"),payment_method:fd.get("payment"),items})});
  const data=await res.json(); if(!res.ok){setNotice(data.error||"Не удалось оформить заказ");return;}
  setNotice(`Заказ №${data.order_number} принят. Мы свяжемся с вами для подтверждения.`);setCart({});setCheckout(false);
 }
 return <main>
  <div className="topline">Мясная лавка «Петровские паруса» <span>Свежие продукты • Самовывоз в Коммунарке</span></div>
  <header className="header">
   <a className="brand" href="#"><img src="/logo.png" alt="Петровские паруса"/><span><b>ПЕТРОВСКИЕ ПАРУСА</b><small>МЯСНАЯ ЛАВКА</small></span></a>
   <nav className={mobile?"nav open":"nav"}><a href="#catalog">Каталог</a><a href="#about">О магазине</a><a href="#contacts">Контакты</a></nav>
   <div className="head-actions"><a className="phone" href="tel:+70000000000"><Phone size={16}/> Позвонить</a><button className="cart-btn" onClick={()=>setCheckout(true)}><ShoppingBag size={18}/> Корзина <i>{count}</i></button><button className="mobile-menu" onClick={()=>setMobile(!mobile)}><Menu/></button></div>
  </header>
  <section className="hero"><div className="hero-copy"><span className="eyebrow">МЯСНАЯ ЛАВКА У ДОМА</span><h1>Хорошее мясо.<br/><em>Правильный выбор.</em></h1><p>Отборные продукты для семейного стола, любимых рецептов и особенных поводов.</p><a href="#catalog" className="primary">Выбрать продукты <span>→</span></a><div className="hero-note"><b>01</b><span>Выбирайте продукты онлайн<br/>и забирайте в удобное время</span></div></div><div className="hero-image"><div className="hero-stamp">КАЧЕСТВО<br/>В КАЖДОМ<br/>КУСОЧКЕ</div></div></section>
  <section className="benefits"><div><b>01</b><span><strong>Отборные продукты</strong><small>Внимание к качеству</small></span></div><div><b>02</b><span><strong>Удобный заказ</strong><small>Пара минут — и готово</small></span></div><div><b>03</b><span><strong>Самовывоз</strong><small>Коммунарка, Липовый парк</small></span></div></section>
  <section id="catalog" className="catalog section"><div className="section-heading"><div><span className="eyebrow">НАШ АССОРТИМЕНТ</span><h2>Выбирайте <em>своё</em></h2></div><label className="search"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Найти продукт"/></label></div>
   <div className="chips">{categories.map(c=><button key={c} className={category===c?"chip active":"chip"} onClick={()=>setCategory(c)}>{c}</button>)}</div>
   <div className="products">{shown.map((p,i)=><article className="product" key={p.id}><div className="product-image">{p.image_url?<img src={p.image_url} alt={p.name}/>:<div className="placeholder">ПП</div>}<span className="product-number">0{i+1}</span></div><div className="product-info"><small>{p.category}</small><h3>{p.name}</h3><p>{p.description}</p><div className="product-bottom"><strong>{money(p.price)} <small>/ {p.unit}</small></strong><button onClick={()=>add(p.id)} aria-label="Добавить в корзину"><Plus size={19}/></button></div></div></article>)}</div>
  </section>
  <section id="about" className="about"><div className="about-photo"></div><div><span className="eyebrow">ПЕТРОВСКИЕ ПАРУСА</span><h2>Вкус начинается<br/><em>с хорошего продукта</em></h2><p>Мы создаём место, где удобно выбирать продукты для повседневных блюд и семейных встреч. Заказывайте онлайн и забирайте покупки в нашей лавке.</p><a href="#contacts" className="text-link">Как нас найти <span>→</span></a></div></section>
  <footer id="contacts"><div className="footer-main"><div><img src="/logo.png" alt="" className="footer-logo"/><h3>ПЕТРОВСКИЕ ПАРУСА</h3><p>Мясная лавка у дома</p></div><div><span className="eyebrow">МЫ ЖДЁМ ВАС</span><p><MapPin size={17}/> Москва, посёлок Коммунарка,<br/>Липовый парк, 4, корп. 1</p><p><Phone size={17}/> Телефон уточняется</p></div><div><span className="eyebrow">ПОЛУЧЕНИЕ ЗАКАЗА</span><p>Самовывоз из магазина</p><p>Оплата онлайн или при получении</p></div></div><div className="copyright">© {new Date().getFullYear()} Петровские паруса. Все права защищены.</div></footer>
  {notice&&<div className="toast" onClick={()=>setNotice("")}>{notice}<button><X size={16}/></button></div>}
  {checkout&&<div className="overlay" onClick={()=>setCheckout(false)}><div className="drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><h2>Ваш заказ</h2><button onClick={()=>setCheckout(false)}><X/></button></div>{count===0?<p className="empty">Корзина пока пуста. Добавьте товары из каталога.</p>:<><div className="cart-lines">{products.filter(p=>cart[p.id]).map(p=><div className="cart-line" key={p.id}><div><b>{p.name}</b><small>{money(p.price)} / {p.unit}</small></div><div className="qty"><button onClick={()=>change(p.id,-1)}><Minus size={14}/></button>{cart[p.id]}<button onClick={()=>change(p.id,1)}><Plus size={14}/></button></div><strong>{money(p.price*cart[p.id])}</strong></div>)}</div><div className="total"><span>Итого</span><b>{money(total)}</b></div><form onSubmit={submit} className="order-form"><h3>Оформление самовывоза</h3><label>Ваше имя<input name="name" required placeholder="Как к вам обращаться"/></label><label>Телефон<input name="phone" required type="tel" placeholder="+7 (___) ___-__-__"/></label><label>Способ оплаты<select name="payment"><option value="cash_on_pickup">При получении</option><option value="online">Онлайн (подключается)</option></select></label><label>Комментарий<textarea name="comment" placeholder="Пожелания к заказу"/></label><p className="pickup-note"><MapPin size={16}/> Самовывоз: Москва, Коммунарка, Липовый парк, 4, корп. 1</p><button className="primary full" type="submit">Подтвердить заказ</button><small className="fineprint">Онлайн-оплата пока не активирована. Заказ будет принят, а оплату можно будет подключить после настройки эквайринга.</small></form></>}</div></div>}
 </main>;
}